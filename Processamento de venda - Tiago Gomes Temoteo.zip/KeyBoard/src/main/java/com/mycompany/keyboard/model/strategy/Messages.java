/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.keyboard.model.strategy;

/**
 *
 * @author Tiago
 */
public class Messages {
    
    public static String campoObrigatorio (String nomeCampo) { return "O campo "+nomeCampo+" é obrigatório"; };
    public static String usuarioInvalido () { return "Usuário ou Senha Inválidos!"; };
}
